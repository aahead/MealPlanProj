clear = document.getElementById("clearButton") // Get the buttons value
clear.addEventListener('click', function(){ // anonymous function to reload the page when clear is pressed
location.reload() // reloads page
})

document.getElementById("myButton").addEventListener('click', function(event){ // Waits for the button to be clicked and runs anonymous func when it is
    breakChoice = document.getElementById("breakInput").value; // these are just calling input variables from the html file and retrieving there values
    snack1Choice = document.getElementById("snack1Input").value;
    lunchChoice = document.getElementById("lunchInput").value;
    snack2Choice = document.getElementById("snack2Input").value;
    dinnerChoice = document.getElementById("dinnerInput").value;
    uName = document.getElementById("userNameInput").value;
    email = document.getElementById("emailInput").value;
    goal = document.getElementById("goalInput").value;
    regEmail = /^[^@]+@[^@]+\.[^@]+$/ // regex statement to validate emails
        
        if (regEmail.test(email)) { // testing the email entered against the regex
            myText = ("<html>\n<head>\n<title>Welcome</title>\n</head>\n<body>\n"); // starting the html code in the new window
            for (let i = 1; i < 8; i++){ // for loop to print the following code 7 times.
                myText += ("Day " + i + "<br>") // prints what day of the week it is.
                myText += ("Breakfast is: " + breakChoice + ". <br>") // lines 21 - 25 will print to the new window the user input
                myText += ("Snack 1 is: " + snack1Choice + ". <br>")
                myText += ("Lunch is: " + lunchChoice + ". <br>")
                myText += ("Snack 2 is: " + snack2Choice + ". <br>")
                myText += ("Dinner is: " + dinnerChoice + ". <hr>");
            }
            
            myText += ("<input type = \"button\" id = \"printButton\" value = \"Print/Download\">") // a new button element in the new window
            myText += (`<script>button = document.getElementById(\"printButton\")
                button.addEventListener('click', function(){
                window.print()})</script>`) // makes the button open the print menu when pressed and also allows you to download
            myText += ("</body>\n</html>"); // ends the html for the new window
    
            flyWindow = window.open('about:blank','myPop','width=400,height=200,left=200,top=200'); // opens the new blank window
            flyWindow.document.write(myText);  // runs the code written to the my text variable
        } else { 
            event.preventDefault() // if the email is incorrect then the page will not refresh
        }
    })